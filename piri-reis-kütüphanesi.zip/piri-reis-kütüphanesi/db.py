import sqlite3

def checkSetup():
    conn = sqlite3.connect('library_administration.db')
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='admin'")
    result = cursor.fetchone()
    conn.close()
    if result is None:
        return False
    return True

def setup():
    conn = sqlite3.connect('library_administration.db')
    cursor = conn.cursor()
    create_admin_table = """
        CREATE TABLE IF NOT EXISTS admin (
            "id"	TEXT NOT NULL,
			"isim"	TEXT NOT NULL,
			"parola"	TEXT NOT NULL,
			"secSoru"	TEXT NOT NULL,
			"secCevap"	TEXT NOT NULL,
			"Telefon"	INTEGER NOT NULL CHECK(10),
			"Sehir"	TEXT NOT NULL
        );
    """
    create_books_table = """
        CREATE TABLE IF NOT EXISTS books (
            "Kitap_Id"	INTEGER NOT NULL UNIQUE,
			"Kitap_isim"	TEXT NOT NULL,
			"yazar"	TEXT NOT NULL,
			"musait degil"	BOOLEAN NOT NULL,
			PRIMARY KEY("Kitap_Id") 
        );
    """
    create_issue_table = """
        CREATE TABLE IF NOT EXISTS issue (
            "kitapID"	INTEGER NOT NULL,
			"ogrenciID"	INTEGER NOT NULL,
			"duzenleme_tarihi"	DATE NOT NULL,
			"donus_tarihi"	DATE NOT NULL,
			PRIMARY KEY("kitapID","ogrenciID"),
			FOREIGN KEY("kitapID") REFERENCES "kitaplar"("kitap_Id"),
			FOREIGN KEY("ogrenciID") REFERENCES "ogrenciler"("ogrenci_Id")
        );
    """
    create_students_table = """
        CREATE TABLE IF NOT EXISTS students (
            "Roll_no"	INTEGER NOT NULL UNIQUE,
			"isim"	TEXT NOT NULL,
			"Ogrenci_Id"	INTEGER NOT NULL UNIQUE,
			"sinif"	INTEGER NOT NULL,
			"telefon_numarasi"	INTEGER NOT NULL CHECK(10),
			"goruntu"	BLOB NOT NULL,
			"Cikarilan_kitaplar"	INTEGER NOT NULL DEFAULT 0,
			"para cezasi"	INTEGER NOT NULL DEFAULT 0,
			PRIMARY KEY("ogrenci_Id","Roll_no")
        );
    """
    # ogrenci_giris_tablosu_olustur = """
    #     MEVCUT DEGILSE TABLO OLUSTURUN ogrenci girisi (
    #       id INTEGER UNIQUE NOT NULL ,
    #       Std_Id INTEGER NOT NULL ,
    #       password TEXT NOT NULL,
    #       FOREIGN KEY("Std_Id") REFERENCES "students"("Student_Id")
    #       );
    # """
    cursor.execute(create_admin_table)
    cursor.execute(create_books_table)
    cursor.execute(create_issue_table)
    cursor.execute(create_students_table)
    # imlec_yurutmek(ogrenci_giris_tablosu_olustur)
    conn.commit()
    conn.close()


def getConnection():
    return sqlite3.connect('library_administration.db')
