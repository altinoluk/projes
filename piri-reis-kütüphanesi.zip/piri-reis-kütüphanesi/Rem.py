from tkinter import *
from tkinter import messagebox
import sqlite3
from sqlite3 import Error
#pencere oluşturmak
class Rem(Tk):
    def __init__(self):
        super().__init__()
        self.iconbitmap(r'libico.ico')
        self.maxsize(400, 200)
        self.minsize(400, 200)
        self.title("Kullanıcıyı Kaldır")
        self.canvas = Canvas(width=1366, height=768, bg='black')
        self.canvas.pack()
        self.photo = PhotoImage(file='rem.png')
        self.canvas.create_image(-20, -20, image=self.photo, anchor=NW)
        a = StringVar()
        def ent():
            if len(a.get()) < 5:
                messagebox.showinfo("Hata","Lütfen Geçerli Bir Kimlik Girin")
            else:
                d = messagebox.askyesno("Onaylamak", "Kullanıcı kaldırmak istediğinizden emin misiniz?")
                if d:
                    try:
                        self.conn = sqlite3.connect('library_administration.db')
                        self.myCursor = self.conn.cursor()
                        self.myCursor.execute("Kimliğin bulunduğu yöneticiden silin. = ?",[a.get()])
                        temp = self.myCursor.fetchone()
                        if not temp:
                            messagebox.showinfo("Oop's","Kullanıcı bulunamadı")
                            a.set("")
                        else:
                            self.conn.commit()
                            self.myCursor.close()
                            self.conn.close()
                            messagebox.showinfo("Onaylamak","Kullanıcı Başarıyla Kaldırıldı")
                            a.set("")
                    except:
                        messagebox.showerror("Hata","Bir şeyler yanlış gidiyor")
        Label(self, text = "Kullanıcı Kimliğini Girin: ",bg='black',fg='white',font=('Arial', 15, 'bold')).place(x = 20,y = 40)
        Entry(self,textvariable = a,width = 37).place(x = 160,y = 44)
        Button(self, text='Remove', width=15, font=('arial', 10),command = ent).place(x=200, y = 90)



Rem().mainloop()