# Kullanım:
1. Sayı Kitabı
2. Kitabı Yenile
3. İade Kitabı
4. Öğrenci Ara
5. Kitap Ara
6. Kullanıcı Ekle
7. Kullanıcıyı Kaldır
8. Öğrenci Ekle
9. Öğrenciyi Kaldır
10. Kitap Ekle
11. Kitabı Kaldır

# Kısa Tanıtım

Bir öğrenci 03 gün süreyle kitap basabilir.Bundan sonra öğrenci kitabı yenilemek zorundadır, Öğrenci iade tarihi içinde kitabı yenilemediyse 1 Rs/gün ceza ödemek zorundadır. en fazla 3 kitap......