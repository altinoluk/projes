from tkinter import *
import sqlite3
from sqlite3 import Error
from tkinter import messagebox


class Set(Tk):
    def __init__(self):
        super().__init__()
        self.title("Şifreyi belirle")
        self.maxsize(500,300)
        self.minsize(500,300)
        self.canvas = Canvas(width=1366, height=768, bg='black')
        self.canvas.pack()
        self.photo = PhotoImage(file='set.png')
        self.canvas.create_image(-20, -20, image=self.photo, anchor=NW)
        self.iconbitmap(r'libico.ico')
        def verify():
            if len(d.get()) == 0:
                messagebox.showinfo("Hata","Lütfen Kullanıcı Kimliğinizi Girin")
            elif len(a.get()) < 4 and len(b.get()) < 4 and len(c.get()) < 4:
                messagebox.showinfo("Hata","Lütfen geçerli bir Şifre giriniz")
            elif b.get() != c.get():
                messagebox.showinfo("Hata","şifreyi tekrar yazın aynı değil.")
            else:
                try:
                    self.conn = sqlite3.connect('library_administration.db')
                    self.myCursor = self.conn.cursor()
                    self.myCursor.execute("Kimliğin bulundugu yöneticiden şifre seçin.= ?",[d.get()])
                    temp = self.myCursor.fetchone()
                    if temp:
                        if str(temp[0]) == a.get():
                            self.myCursor.execute("Yönetici ayar şifresini güncelle = ? Kimliği nerede = ?",[b.get(),d.get()])
                            self.conn.commit()
                            self.conn.close()
                            messagebox.showinfo("Başarılı","Şifre başarıyla güncellendi")
                        else:
                            messagebox.showinfo("Hata","Eski Şifre Eşleşmiyor")
                    else:
                        messagebox.showinfo("Hata", "Kullanıcı bulunamadı")
                except Error:
                    messagebox.showerror("Hata","Bir şeyler yanlış gidiyor")
            a.set("")
            b.set("")
            c.set("")
            d.set("")
        ulab = Label(self, text="Kullanıcı  kimliği", font=('arial', 15, 'bold')).place(x=40, y=50)
        d = StringVar()
        Uentry= Entry(self, textvariable=d, width=30).place(x=250, y=55)
        olab = Label(self,text="Eski Şifre",font=('arial', 15, 'bold')).place(x=40,y=100)
        a=StringVar()
        entryforoldpasswd = Entry(self,show='*',textvariable=a,width = 30).place(x=250,y=105)
        label = Label(self,text="Yeni Şifre",font=('arial', 15, 'bold')).place(x=40,y=150)
        b=StringVar()
        entryfornewpasswd = Entry(self,show='*',textvariable=b,width = 30).place(x=250,y=155)
        label1 = Label(self,text="Şifreyi tekrar yaz",font=('arial', 15, 'bold')).place(x=40,y=200)
        c=StringVar()
        entryforretypepasswd = Entry(self,show='*',textvariable =c,width = 30).place(x=250,y=205)
        butt=Button(self,text="Değişiklik",width=15,command = verify).place(x=280,y=255)
Set().mainloop()