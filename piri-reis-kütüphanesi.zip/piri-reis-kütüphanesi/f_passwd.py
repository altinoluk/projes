from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import sqlite3
from sqlite3 import Error


#pencere olusturma
class Fp(Tk):
    def __init__(self):
        super().__init__()
        self.iconbitmap(r'libico.ico')
        self.maxsize(480, 320)
        self.title("Sifreyi Unuttum")
        self.canvas = Canvas(width=500, height=500, bg='black')
        self.canvas.pack()
        self.photo = PhotoImage(file='forgot.png')
        self.canvas.create_image(-20, -20, image=self.photo, anchor=NW)
        #degiskenler yaratmak
        a = StringVar()
        b = StringVar()
        c = StringVar()
        d = StringVar()
        e = StringVar()
        #giris dogrulama
        def ins():
            if (len(d.get())) < 8 or len(e.get()) < 8:
                while True:
                    if not re.search("[a-z]", d.get()):
                        flag = -1
                        break
                    elif not re.search("[A-Z]", d.get()):
                        flag = -1
                        break
                    elif not re.search("[0-9]", d.get()):
                        flag = -1
                        break
                    elif not re.search("[_@$]", d.get()):
                        flag = -1
                        break
                    elif re.search("\s", d.get()):
                        flag = -1
                        break
                    else:
                        flag = 0
                        break
                if len(d.get()) == 0:
                    messagebox.showinfo("Hata","Lütfen Sifrenizi Giriniz")
                elif flag == -1:
                    messagebox.showinfo("Hata","En az 8 karakter.\nAlfabeler arasında olmalidir [a-z]\nEn az bir alfabe buyuk harf olmalidir. [A-Z]\nArasinda en az 1 sayi veya rakam. [0-9].\nEn az 1 karakter [ _ or @ or $ ].")
            elif d.get() != e.get():
                messagebox.showinfo("Hata","Yeni şifreyi yeniden yazın")
            else:
                try:
                    self.conn = sqlite3.connect('library_administration.db')
                    self.myCursor = self.conn.cursor()
                    self.myCursor.execute("Yönetici ayar şifresini güncelleyin. = ? Kimliği Nerede = ?",[e.get(),a.get()])
                    self.conn.commit()
                    self.myCursor.close()
                    self.conn.close()
                    messagebox.showinfo("Onaylamak","Şifre başarıyla güncellendi")
                    self.destroy()
                except Error:
                    messagebox.showerror("Hata","Bir şeyler yanlış gidiyor")

        def check():
            if len(a.get()) < 5:
                messagebox.showinfo("Hata","Lütfen Kullanıcı Kimliğini Girin")
            elif len(b.get()) == 0:
                messagebox.showinfo("Hata","Lütfen bir soru seçin")
            elif len(c.get()) == 0:
                messagebox.showinfo("Hata", "Lütfen bir cevap girin")
            else:
                try:
                    self.conn = sqlite3.connect('library_administration.db')
                    self.myCursor = self.conn.cursor()
                    self.myCursor.execute("Select id,secQuestion,secAnswer from admin where id = ?",[a.get()])
                    pc = self.myCursor.fetchone()
                    if not pc:
                        messagebox.showinfo("Hata", "Ayrıntılarda Yanlış Bir Şey Var.")
                    elif str(pc[0]) == a.get() or str(pc[1]) == b.get() or str(pc[2]) == c.get():
                        Label(self, text="Yeni Şifre", font=('arial', 15, 'bold')).place(x=40, y=220)
                        Entry(self, show = "*", textvariable=d, width=40).place(x=230, y=224)
                        Label(self, text="Tekrar Gir", font=('arial', 15, 'bold')).place(x=40, y=270)
                        Entry(self, show = "*", textvariable=e, width=40).place(x=230, y=274)
                        Button(self, text="Göndermek", width=15, command=ins).place(x=230, y=324)
                except Error:
                    messagebox.showerror("Hata","Bir şeyler yanlış gidiyor")

        #etiket ve giris kutusu
        Label(self, text="Kullanıcı Kimliği",bg='black',fg='white', font=('arial', 15, 'bold')).place(x=40, y=20)
        Label(self, text="Güvenlik Sorusu",bg='black',fg='white',font=('arial', 15, 'bold')).place(x=40, y= 70)
        Label(self, text="Güvenlik cevabı",bg='black',fg='white',font=('arial', 15, 'bold')).place(x=40, y= 120)
        Entry(self, textvariable=a, width=40).place(x=230, y=24)
        ttk.Combobox(self, textvariable = b,values=["Okul Adın ne?", "Evinin adı ne?","Baba adın ne?", "Evcil hayvaninin adı ne?"], width=37,state="Sadece oku").place(x=230, y=74)
        Entry(self, show = "*", textvariable=c, width=40).place(x=230, y=124)
        Button(self, text='Doğrulayın', width=15,command = check).place(x=275, y=170)

Fp().mainloop()
