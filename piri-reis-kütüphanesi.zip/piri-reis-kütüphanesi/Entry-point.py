import db
import sys
import os
py=sys.executable


# Basvuru_icin_giris_noktasi
if __name__ == '__main__':
    if not db.checkSetup():
        db.setup()
        os.system('%s %s' % (py, 'Reg.py'))
    else:
        os.system('%s %s' % (py, 'main.py'))
